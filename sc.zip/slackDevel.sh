export SLACK_DEVELOPER_MENU=true; open -a /Applications/Slack.app

